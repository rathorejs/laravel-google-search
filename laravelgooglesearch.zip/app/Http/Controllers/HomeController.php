<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use JanDrda\LaravelGoogleCustomSearchEngine\LaravelGoogleCustomSearchEngine;
use PDF;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public $PAGE_LIMIT = 10;
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {

        $results = [];
        $search = $request->get('search');
        if ($request->get('search')) {
            $parameters = array(
                'start' => $this->PAGE_LIMIT,
                'num' => $this->PAGE_LIMIT
            );
            $fulltext = new LaravelGoogleCustomSearchEngine();
            $results = $fulltext->getResults($request->get('search'), $parameters);
        }
    

        view()->share(['results' => $results, 'search' => $search]);
        if ($request->get('type') == 'pdf') {
            $pdf = PDF::loadView('home')->setOptions(['defaultFont' => 'sans-serif']);
            return $pdf->download($search . '.pdf');
        }
        return view('home');
    }
}
