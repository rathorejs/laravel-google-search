@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    {{ Form::open(['route'=>'home','class'=>'form-horizontal','method'=>'get']) }}
                    <div class="form-group">
                        <div class="col-sm-12">
                            {{ Form::text('search',$search,['class'=>'form-control','required'=>'true','placeholder'=>'Search here...']) }}
                        </div>
                    </div>
                    <div class="form-group">        
                        <div class="col-sm-10">
                            {{ Form::button('Search',['type'=>'submit','class'=>'btn btn-default','name'=>'type','value'=>'search']) }}
                            {{ Form::button('Download as PDF',['type'=>'submit','class'=>'btn btn-default','name'=>'type','value'=>'pdf']) }}
                        </div>
                    </div>
                    {{ Form::close() }} 
                </div>

                <div class="card-body">
                  @if(count($results) > 0)  
                    @foreach($results as $k => $data)
                            <h4><a target="_blank" href="{{ $data->link }}">{{ $data->title }}</a></h4>
                            <p>{{ html_entity_decode(strip_tags($data->htmlSnippet)) }}</p>
                            <br/>
                    @endforeach
                   @else
                   <p>No Record Found.</p>
                   @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
