<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <?php echo e(Form::open(['route'=>'home','class'=>'form-horizontal','method'=>'get'])); ?>

                    <div class="form-group">
                        <div class="col-sm-12">
                            <?php echo e(Form::text('search',$search,['class'=>'form-control','required'=>'true','placeholder'=>'Search here...'])); ?>

                        </div>
                    </div>
                    <div class="form-group">        
                        <div class="col-sm-10">
                            <?php echo e(Form::button('Search',['type'=>'submit','class'=>'btn btn-default','name'=>'type','value'=>'search'])); ?>

                            <?php echo e(Form::button('Download as PDF',['type'=>'submit','class'=>'btn btn-default','name'=>'type','value'=>'pdf'])); ?>

                        </div>
                    </div>
                    <?php echo e(Form::close()); ?> 
                </div>

                <div class="card-body">
                  <?php if(count($results) > 0): ?>  
                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h4><a target="_blank" href="<?php echo e($data->link); ?>"><?php echo e($data->title); ?></a></h4>
                            <p><?php echo e(html_entity_decode(strip_tags($data->htmlSnippet))); ?></p>
                            <br/>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php else: ?>
                   <p>No Record Found.</p>
                   <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_7.3\htdocs\laravelgooglesearch\resources\views/home.blade.php ENDPATH**/ ?>